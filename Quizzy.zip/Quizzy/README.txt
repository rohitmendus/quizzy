Quizzy

Quizzy is an aplication created for fun and do not reflect any other applications. This application acts a quiz software
which can create tests, take test, evaluate it and many more... There are two types of users an admin who can administer
app and a quiztaker who takes the test. If you have installed the app, this is the username and password for you to login
to the app initially and set it up.

User Name: admin1
Password: 12345

If there are any problems or bugs please do inform me. Anyway I know this app doesn't have any good design😀 but since this
was one of my applications I built I think it is would do. Hope you would like the app. Signing off...
Quizzy 1.0 
@rohitmendus
